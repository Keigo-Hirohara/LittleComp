-- AlterTable
ALTER TABLE "Task" ALTER COLUMN "status" SET DEFAULT 'new';
