export type CreateTask = {
  taskName: string;
  storyId: string;
};
