export type RenameTask = {
  targetId: string;
  newName: string;
};
