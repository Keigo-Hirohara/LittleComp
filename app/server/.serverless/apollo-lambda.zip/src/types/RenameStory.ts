export type RenameStory = {
  targetId: string;
  newName: string;
};
