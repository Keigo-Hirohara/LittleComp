export type DeleteStory = {
  targetId: string;
};
