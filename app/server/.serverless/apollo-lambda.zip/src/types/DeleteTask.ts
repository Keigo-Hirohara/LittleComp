export type DeleteTask = {
  targetId: string;
};
