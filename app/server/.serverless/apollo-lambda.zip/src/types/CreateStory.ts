export type CreateStory = {
  name: string;
};
