export type UpdateTaskStatus = {
  targetId: string;
  newStatus: string;
};
